
function add(x = 1, y = 2) {
  return x + y;
} 
console.log(add(5)); // 7
console.log(add(undefined, 1)); // 2

console.log(add());  // 3