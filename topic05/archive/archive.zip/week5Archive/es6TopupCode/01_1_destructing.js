// ARRAY destructuring
{ 
    // without destruction 
	let nums = [10, 11, 12]
	let v1 = nums[0]
	let v2 = nums[1]
	let v3 = nums[2]
}
{
	// with destruction
	let nums = [10, 11, 12]
	let [v1, v2, v3] = nums
	console.log(`1 ${v1} ${v2} ${v3} `)  // 10 11 12 
}
{
	// with destruction
	let nums = [10, 11, 12, 13, 14, 15];
	let [,v2,,,v5] = nums
	console.log(`2 ${v2} ${v5}`)
	let [v1,,v3,v4] = nums;
	console.log(`3 ${v1} ${v3} ${v4}`); // 1
}
