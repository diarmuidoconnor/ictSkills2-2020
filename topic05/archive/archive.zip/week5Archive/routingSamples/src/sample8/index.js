import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";
import { About } from "../sample1";
import Inbox from "../sample3/inbox";
import Register from "../sample7/registerDeclarative";
import Header from "./header";
import Footer from "./footer";
import "../../node_modules/bootstrap/dist/css/bootstrap.css";
import "./app.css";

const Home = () => {
  return (
    <>
      <h1>Home page</h1>
      <h4>
        Try link: <Link to="/inbox/1234">user 1234</Link>
      </h4>
    </>
  );
};

const Contact = () => {
  return <h2>Contact Us page</h2>;
};

const App = () => {
  return (
    <BrowserRouter>
      <div>
        <Header />
        <div className="container">
          <Switch>
            <Route path="/about" component={About} />
            <Route path="/register" component={Register} />
            <Route path="/contact" component={Contact} />
            <Route path="/inbox/:userId" component={Inbox} />
            <Route exact path="/" component={Home} />
            <Redirect from="*" to="/" />
          </Switch>
        </div>
        <Footer />
      </div>
    </BrowserRouter>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
