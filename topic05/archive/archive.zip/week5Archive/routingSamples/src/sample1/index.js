import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch } from "react-router-dom";

export const About = () => {
  return <h2>About page</h2>;
};

export const Inbox = () => {
  return <h2>Inbox page</h2>;
};


const SharedComponent = (props) => {
  . . . get person data from API . . . 
  return (
    <div className='classX'>
      {this.props.render(person.name)}
  </div>
  )
};
const SayHello = (props) => {  
  return (
    <SharedComponent render={(name) => (
    <span>hello! {name}</span>
    )} />
  )
}

const CommentList = (props) => {
  return (
    <div className='classX'>
      . . . map over comments array
    </div>
  )
};

const BlogPostAndComments = (props) => { 
  . . . hooks and other logic . . .  
  return (
    <>
       <TextBlock text={....} />
       <CommentList  />
    </>
  )
}
const BlogPostAndMatches = (props) => {  
  . . . hooks and other logic . . .  
  return (
    <>
       <TextBlock text={....} />
       <BlogMatches />
    </>
  )
}

const BlogPost = (props) => {  
  . . . query API for blog . . . . . 
  return (
    <>
       <TextBlock text={} />
       {this.props.render(blog.id)}
    </>
  )
}

const BlogPostAndComments = (props) => { 
  return (
    <>
       <BlogPost 
          render={(blogId) => <CommentList /> } />
    </>
  )
}

const BlogPostAndMatches = (props) => { 
  return (
    <>
       <BlogPost 
         render={(blogId) => <PostMatches /> } />
    </>
  )
}

const Home = () => {
  return <h1>Home page</h1>;
};

const App = () => {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/about" component={About} />
        <Route path="/inbox" component={Inbox} />
        <Route exact path="/" component={Home} />
        <Redirect from="*" to="/" />
      </Switch>
    </BrowserRouter>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
