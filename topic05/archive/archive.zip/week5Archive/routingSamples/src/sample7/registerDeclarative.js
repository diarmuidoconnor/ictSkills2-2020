import React, { useState } from "react";
import { Redirect } from "react-router-dom";

export default function() {
  const [toHome, setToHome] = useState(false);

  const handleSubmit = user => {
    // save user to datastore
    setToHome(true);
  };

  if (toHome === true) {
    return <Redirect to="/" />;
  }
  return (
    <>
      <h2>Registration Form</h2>
      <button onClick={handleSubmit}>Register</button>
    </>
  );
};
