This archive contains the source code for the Friends List app discussed
in the lectures. The two design forms are included, titled:
1. 1 way data flow
2. Inverse data flow

Both projects were created with the create-react-app tool. To run either of them, go to 
the project's base folder, e.g. 1WayDataFlow, and from the command line type:

    $ npm install
    $ npm start

