This folder contains the Sample App 2 code discussed in the lecture - the redesigned Filtered Friends app. It was created with the create-react-app tool.

To run it:

$ npm install]]
$ npm start

The code demonstrates:
- Data down, action up pattern.