import React, { memo} from "react";


function areEqual(prevProps, nextProps) {
    return prevProps.friend.name.first === nextProps.friend.name.first;
    // return prevProps.contact.phone === nextProps.contact.phone
  }
const Friend = props => {
  console.log(
    `Render of Friend (${props.friend.name.first} ${props.friend.name.last})`
  );
  return (
    <li>
      <h3>{` ${props.friend.name.first} ${props.friend.name.last}`}</h3>
      <a href={"mailto:" + props.friend.email}>
        {props.friend.email}{" "}
      </a>
    </li>
  );
};

export default memo(Friend,areEqual)